import { Context } from "telegraf";
import { brainstorm } from "../brainstorm/brainstorm.engine.js";
import {
  getConversation,
  addMessage,
  clearConversation,
  getOrCreateTopic,
  getTopicMessages,
} from "../memory/conversation.memory.js";

const BOT_USERNAME = "zethus_brainstorm_bot";

export async function textMessageHandler(ctx: Context): Promise<void> {
  if (!ctx.message || !("text" in ctx.message)) {
    return;
  }

  const message = ctx.message;
  const text = message.text.trim();

  const chatType = ctx.chat?.type;

  // Private chat
  const isPrivateChat = chatType === "private";

  // Group
  const botMention = `@${BOT_USERNAME}`;

  if (!isPrivateChat) {
    if (!text.toLowerCase().includes(botMention.toLowerCase())) {
      return;
    }
  }

  // Remove the bot mention if it exists.
  const question = text
    .replace(new RegExp(`@${BOT_USERNAME}\\b`, "gi"), "")
    .trim();

  if (!question) {
    await ctx.reply("🧠 What would you like to brainstorm about?");
    return;
  }

  console.log("🧠 Brainstorm question:", question);

  try {
    await ctx.sendChatAction("typing");

    const username =
      ctx.from?.username ?? ctx.from?.first_name ?? "Unknown user";

    const conversationId = String(ctx.chat!.id);

    const topic = getOrCreateTopic(conversationId, question);
    console.log(`🧠 Topic selected: "${topic.name}" (${topic.id})`);

    const conversationHistory = getTopicMessages(conversationId, topic.id);
    console.log(`📚 Topic history: ${conversationHistory.length} messages`);

    const response = await brainstorm(question, conversationHistory, username);

    addMessage(
      conversationId,
      {
        role: "user",
        content: question,
        userId: String(ctx.from?.id),
        username,
      },
      topic.id,
    );

    addMessage(
      conversationId,
      {
        role: "assistant",
        content: response,
      },
      topic.id,
    );

    await ctx.reply(response);
  } catch (error) {
    console.error("❌ Brainstorm error:", error);

    await ctx.reply(
      "❌ Sorry, I could not generate a brainstorming response right now.",
    );
  }
}

export async function clearCommandHandler(ctx: Context): Promise<void> {
  const conversationId = String(ctx.chat!.id);

  console.log("🧹 Clearing conversation:", conversationId);

  clearConversation(conversationId);

  console.log("🧹 Conversation after clear:", getConversation(conversationId));

  await ctx.reply("🧹 Conversation cleared. Let's start fresh!");
}
